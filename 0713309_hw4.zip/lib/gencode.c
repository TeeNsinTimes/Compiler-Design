#include "symtab.h"
#include "gencode.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define gen(fmt, ...) fprintf(fd, fmt, ##__VA_ARGS__)
#define SHOW(M) if (show) printf("Enter %s\n", M)

int show = 1;

FILE *fd;
char *prog;
extern char* output;

int depth;
int label_num;

void print(char *instr) {
  SHOW("print");
  fprintf(fd, "\t%s\n", instr);
}
void genHeader(char *fname) {
  SHOW("genHeader");
  fprintf(fd, ".class public %s\n.super java/lang/Object\n", fname);
}
int getArraySize(struct ArrayDsrpt *dsrpt) {
  int lower, upper;
  if(dsrpt->lowerBound->defined == 0) {
    fprintf(stderr, "Runtime retrieve array bound is not implemented\n"); exit(1);
  } else { lower = dsrpt->lowerBound->value; }
  if(dsrpt->upperBound->defined == 0) {
    fprintf(stderr, "Runtime retrieve array bound is not implemented\n"); exit(1);
  } else { upper = dsrpt->upperBound->value; }
  switch(dsrpt->type) {
  case TypeInt: { return (upper-lower+1); }
  case TypeReal: { return (upper-lower+1)*2; }
  case TypeArray: { return (upper-lower+1)*getArraySize(dsrpt->typeDsrpt); }
  default: { fprintf(stderr, "[ERROR] Array Type of %d is undefined\n", dsrpt->type); exit(1); }
  }
}
int genVar(int depth) {
  SHOW("Enter genVar");
  int num = 0;
  int index = SymbolTable.scopes[depth];
  printf("depth = %d\n", depth);
  while(index != -1) { // assign Jasmine local index to global variables
    printf("For index %d\n", index);
    SHOW(SymbolTable.entries[index].name);
    switch(SymbolTable.entries[index].type) {
      case TypeInt: {
        SymbolTable.entries[index].index = num++;
        break;
      }
      case TypeReal: {
        SymbolTable.entries[index].index = num;
        num += 2;
        break;
      }
      case TypeArray: {
        SymbolTable.entries[index].index = num;
        int size = getArraySize(SymbolTable.entries[index].typeDsrpt);
        num += size;
        break;
      }
    }
    index = SymbolTable.entries[index].next;
    printf("next index is %d\n", index);
  }
  return num+2;
}
char* genArraySig(struct ArrayDsrpt *dsrpt) {
  switch(dsrpt->type) {
  case TypeInt: { return "[I"; }
  case TypeReal: { return "[F"; }
  case TypeChar: { return "[Ljava/lang/String;"; }
  case TypeArray: { char *sig = (char *)malloc(sizeof(char)*MAX_SIG); strcpy(sig, "["); strcat(sig, genArraySig(dsrpt->typeDsrpt)); return sig; }
  default: { fprintf(stderr, "[ERROR] Array Type of %d is undefined\n", dsrpt->type); exit(1); }
  }
}
void genGlobalVar() {
  int index = SymbolTable.scopes[0];
  while(index != -1) { // assign Jasmine fieled index to global variables
    switch(SymbolTable.entries[index].type) {
      case TypeInt: {
        SHOW("genGlobalVarInt");
        SymbolTable.entries[index].index = -1;
        fprintf(fd, ".field public static %s I\n", SymbolTable.entries[index].name);
        break;
      }
      case TypeReal: {
        SHOW("genGlobalVarReal");
        SymbolTable.entries[index].index = -1;
        fprintf(fd, ".field public static %s F\n", SymbolTable.entries[index].name);
        break;
      }
      case TypeChar: {
        SHOW("genGlobalVarChar");
        SymbolTable.entries[index].index = -1;
        fprintf(fd, ".field public static %s Ljava/lang/String;\n", SymbolTable.entries[index].name);
        break;
      }
      case TypeArray: {
        SHOW("genGlobalVarTypeArray");
        SymbolTable.entries[index].index = -1;
        fprintf(fd, ".field public static %s %s\n", SymbolTable.entries[index].name, genArraySig(SymbolTable.entries[index].typeDsrpt));
        break;
      }
    }
    index = SymbolTable.entries[index].next;
  }
}
char* genField(char *name) {
  char *rst = (char *)malloc(sizeof(char)*MAX_SIG);
  strcpy(rst, name);
  int index = findSymbolAt(name, 0);
  switch(SymbolTable.entries[index].type) {
  case TypeInt: { strcat(rst, " I"); return rst; }
  case TypeReal: { strcat(rst, " F"); return rst; }
  case TypeChar: { strcat(rst, " Ljava/lang/String;"); return rst; }
  default: { strcat(rst, " "); strcat(rst, genArraySig(SymbolTable.entries[index].typeDsrpt)); return rst; }
  }
}
void genArrayRange(struct ArrayDsrpt *dsrpt) {
  int lower, upper;
  lower = dsrpt->lowerBound->value; upper = dsrpt->upperBound->value;
  SHOW("genArrayRange");
  fprintf(fd, "\tbipush %d\n", (upper-lower+1));
  if(dsrpt->type == TypeArray)
    genArrayRange(dsrpt->typeDsrpt);
}
void allocArray(int index, char *fname) {
  struct ArrayDsrpt *dsrpt = SymbolTable.entries[index].typeDsrpt;
  if(dsrpt->dimension > 1) {
    genArrayRange(dsrpt);
    fprintf(fd, "\tmultianewarray %s %d\n", genArraySig(dsrpt), dsrpt->dimension);
  } else {
    genArrayRange(dsrpt);
    switch(dsrpt->type) {
    case TypeInt: fprintf(fd, "\tnewarray int\n"); break;
    case TypeReal: fprintf(fd, "\tnewarray double\n"); break;
    case TypeChar: fprintf(fd, "\tanewarray java/lang/String\n"); break;
    default: fprintf(stderr, "Array Type of %d not implemented\n", dsrpt->type); exit(1);
    }
  }
  if(SymbolTable.entries[index].index == -1) {
    fprintf(fd, "\tputstatic %s.%s\n", fname, genField(SymbolTable.entries[index].name));
  }
  else fprintf(fd, "\tastore %d\n", SymbolTable.entries[index].index);
}
void genAllocArray(int depth, char *fname) {
  int index = SymbolTable.scopes[depth];
  while(index != -1) {
    if(SymbolTable.entries[index].type == TypeArray) allocArray(index, fname);
    index = SymbolTable.entries[index].next;
  }
}
void genBodyHead(char *fname, int varnum) {
  fprintf(fd, ".method public static main([Ljava/lang/String;)V\n\t.limit stack %d\n\t.limit locals %d\n", varnum*2, varnum);
}
void genBodyEnd() { fprintf(fd, "\treturn\n.end method");}
char* sigType(struct DsrptType *dtype) {
  enum StdType type = dtype->type;
  switch(type) {
    case TypeInt: return "I";
    case TypeReal: return "F";
    case TypeChar: return "Ljava/lang/String;";
    case TypeArray: return genArraySig(dtype->typeDsrpt);
    default: { fprintf(stderr, "[ERROR] %s not implemented yet\n", displayType(dtype)); exit(1); }
  }
}
char* genSignature(char *funproc_name) {
  char *signature = (char *)malloc(sizeof(char)*MAX_SIG);
  strcpy(signature, funproc_name);
  strcat(signature, "(");
  int index = findSymbolAt(funproc_name, 0);
  struct SymTableEntry entry = SymbolTable.entries[index];
  switch(entry.type) {
    case TypeFun: {
      struct FunctionDsrpt *funDef = entry.typeDsrpt;
      int i;
      for(i=0;i<funDef->paramNum;i++) strcat(signature, sigType(funDef->paramType[i]));
      strcat(signature, ")");
      strcat(signature, sigType(funDef->retType));
      return signature;
    }
    case TypeProc: {
      struct ProcedureDsrpt *procDef = entry.typeDsrpt;
      int i; for(i=0;i<procDef->paramNum;i++) strcat(signature, sigType(procDef->paramType[i]));
      strcat(signature, ")V");
      return signature;
    }
    default: {
      printf(stderr, "[ERROR] %s must be a function or procedure\n", funproc_name);
      exit(1);
    }
  }
}
void genMethodDeclar() {
  fprintf(fd, ".method public static writelnI(I)V\n"
      ".limit locals 5\n"
      ".limit stack 5\n"
      "    getstatic java/lang/System/out Ljava/io/PrintStream;\n"
      "    iload 0\n"
      "    invokevirtual java/io/PrintStream/println(I)V\n"
      "    return\n"
      ".end method\n"
      "\n"
      ".method public static writelnR(" "F" ")V\n"
      "    .limit locals 5\n"
      "    .limit stack 5\n"
      "    getstatic java/lang/System/out Ljava/io/PrintStream;\n"
      "    " "f" "load 0\n"
      "    invokevirtual java/io/PrintStream/println(" "F" ")V\n"
      "    return\n"
      ".end method\n"
      "\n"
      ".method public static writelnS(Ljava/lang/String;)V\n"
      "    .limit locals 5\n"
      "    .limit stack 5\n"
      "    getstatic java/lang/System/out Ljava/io/PrintStream;\n"
      "    aload 0\n"
      "    invokevirtual java/io/PrintStream/println(Ljava/lang/String;)V\n"
      "    return\n"
      ".end method\n"
      "\n"
      ".method public static readlnI()I\n"
      "    .limit locals 10\n"
      "    .limit stack 10\n"
      "    ldc 0\n"
      "    istore 1\n"
      "LAB1:\n"
      "    getstatic java/lang/System/in Ljava/io/InputStream;\n"
      "    invokevirtual java/io/InputStream/read()I\n"
      "    istore 2\n"
      "    iload 2\n"
      "    ldc 10\n"
      "    isub\n"
      "    ifeq LAB2\n"
      "    iload 2\n"
      "    ldc 32\n"
      "    isub\n"
      "    ifeq LAB2\n"
      "    iload 2\n"
      "    ldc 48\n"
      "    isub\n"
      "    ldc 10\n"
      "    iload 1\n"
      "    imul\n"
      "    iadd\n"
      "    istore 1\n"
      "    goto LAB1\n"
      "LAB2:\n"
      "    iload 1\n"
      "    ireturn\n"
      ".end method\n\n");
  fprintf(fd, ".method public <init>()V\n\taload_0\n\tinvokenonvirtual java/lang/Object/<init>()V\n\treturn\n.end method\n");
  /* printInt, printReal, printString */
  fprintf(fd, ".method public static printInt(I)V\n\t.limit locals 1\n\t.limit stack 2\n\tgetstatic java/lang/System/out Ljava/io/PrintStream;\n\tiload_0\n\tinvokevirtual java/io/PrintStream/println(I)V\n\treturn\n.end method\n.method public static printReal(D)V\n\t.limit locals 2\n\t.limit stack 3\n\tgetstatic java/lang/System/out Ljava/io/PrintStream;\n\tdload_0\n\tinvokevirtual java/io/PrintStream/println(D)V\n\treturn\n.end method\n.method public static printString(Ljava/lang/String;)V\n\t.limit locals 1\n\t.limit stack 2\n\tgetstatic java/lang/System/out Ljava/io/PrintStream;\n\taload_0\n\tinvokevirtual java/io/PrintStream/println(Ljava/lang/String;)V\n\treturn\n.end method\n\n");
}
int checkReference(struct nodeType *node) {
  int index = findSymbolAll(node->string, depth);
  if(SymbolTable.entries[index].type == TypeArray) return 1;
  return 0;
}
int genSimpleLHS(struct nodeType *node) {
  printf("enter gen simple lhs\n");
  int index = findSymbolAll(node->string, depth);
  printf("node->string = %s\n", node->string);
  printf("index = %d\n", index);
  if(index == -1) {
    SHOW("NOT FOUND");
    SHOW(node->string);
    fprintf(stderr, "[ERROR] %s not found at scope %d\n", node->string, depth);
  }
  return SymbolTable.entries[index].index;
}
void genArrayLHS(struct nodeType *node, char *fname) {
  struct nodeType *nameNode = nthChild(1, node); struct nodeType *dList = nthChild(2, node);
  int index = genSimpleLHS(nameNode);
  if(index == -1) {
    int idx = findSymbolAt(nameNode->string, 0);
    fprintf(fd, "\tgetstatic %s.%s\n", fname, genField(nameNode->string));
  } else fprintf(fd, "\taload %d\n", index);
  struct nodeType *idNode = dList->child;
  struct nodeType **nodes = malloc(sizeof(struct nodeType *)*MAX_DIM);
  int paraN; int i = 0; do { nodes[i] = idNode; i++; idNode = idNode->rsibling; } while(idNode != dList->child); paraN = i;
  index = findSymbolAll(nameNode->string, depth);
  struct ArrayDsrpt *arrayD = SymbolTable.entries[index].typeDsrpt;
  for(i=paraN-1; i>=0; i--) {
    genCode(nodes[i], fname);
    fprintf(fd, "\tldc %d\n\tisub\n", arrayD->lowerBound->value);
    if(i>0) fprintf(fd, "\taaload\n");
    arrayD = arrayD->typeDsrpt;
  }
}
void genArrayRef(struct nodeType *node, char *fname) {
  struct nodeType *nameNode = nthChild(1, node); struct nodeType *dList = nthChild(2, node);
  int index = genSimpleLHS(nameNode);
  if(index == -1) {
    fprintf(fd, "\tgetstatic %s.%s\n", fname, genField(nameNode->string));
  }
  else fprintf(fd, "\taload %d\n", index);
  index = findSymbolAll(nameNode->string, depth);
  struct nodeType *idNode = dList->child; struct nodeType **nodes = malloc(sizeof(struct nodeType *)*MAX_DIM);
  int paraN; int i = 0; do { nodes[i] = idNode; i++; idNode = idNode->rsibling; } while(idNode != dList->child); paraN = i;
  struct ArrayDsrpt *arrayD = SymbolTable.entries[index].typeDsrpt;
  for(i=paraN-1; i>=0; i--) {
    genCode(nodes[i], fname);
    fprintf(fd, "\tldc %d\n\tisub\n", arrayD->lowerBound->value);
    if(i>0) fprintf(fd, "\taaload\n");
    else {
      switch(arrayD->type) {
      case TypeInt: {
        print("iaload");
        //print("invokestatic test_array_slice.writelnI(I)V");
        return;
      }
      case TypeReal: print("daload"); return;
      case TypeChar: print("aaload"); return;
      default: {}//fprintf(stderr, "Array Type of %d not implemented\n", arrayD->type); exit(1);
      }
    }
    arrayD = arrayD->typeDsrpt;
  }
}
char* genLabel() {
  char *label = (char *)malloc(sizeof(char)*MAX_LABEL);
  char *num = malloc(sizeof(char)*(MAX_LABEL-1)); sprintf(num, "%d", label_num);
  strcpy(label, "L"); strcat(label, num); label_num++;
  return label;
}
void negateOperator(struct nodeType *node) {
  switch(node->op) {
  case OP_GT: node->op = OP_LE; break;
  case OP_LT: node->op = OP_GE; break;
  case OP_GE: node->op = OP_LT; break;
  case OP_LE: node->op = OP_GT; break;
  case OP_EQ: node->op = OP_NE; break;
  case OP_NE: node->op = OP_EQ; break;
  case OP_NOT: node->op = OP_NO; break;
  case OP_NO: node->op = OP_NOT; break;
  }
}
void genPredicate(struct nodeType *node, char *nlabel, char *fname) {
  SHOW("genPredicate\n");
  switch(node->op) {
  case OP_GT:
  case OP_LT:
  case OP_GE:
  case OP_LE: {
    struct nodeType *Lexp = nthChild(1, node);
    struct nodeType *Rexp = nthChild(2, node);
    genCode(Lexp, fname);
    genCode(Rexp, fname);
    switch(Lexp->valueType) {
      case TypeInt: {
        switch(node->op) {
          case OP_GT: {
            SHOW("Int OP_GT");
            fprintf(fd, "\tif_icmple %s\n", nlabel);
            return;
          }
          case OP_LT: {
            SHOW("Int OP_LT");
            fprintf(fd, "\tif_icmpge %s\n", nlabel);
            return;
          }
          case OP_GE: {
            SHOW("Int OP_GE");
            fprintf(fd, "\tif_icmplt %s\n", nlabel);
            return;
          }
          case OP_LE: {
            SHOW("Int OP_LE");
            fprintf(fd, "\tif_icmpgt %s\n", nlabel);
            return;
          }
        }
        break;
      }
      case TypeReal: {
        switch(node->op) {
          case OP_GT: {
            SHOW("Real OP_GT");
            fprintf(fd, "\tdcmpl\n\tifle %s\n", nlabel);
            return;
          }
          case OP_LT: {
            SHOW("Real OP_LT");
            fprintf(fd, "\tdcmpg\n\tifge %s\n", nlabel);
            return;
          }
          case OP_GE: {
            SHOW("Real OP_GE");
            fprintf(fd, "\tdcmpl\n\tiflt %s\n", nlabel);
            return;
          }
          case OP_LE: {
            SHOW("Real OP_LE");
            fprintf(fd, "\tdcmpg\n\tifgt %s\n", nlabel);
            return;
          }
        }
        break;
      }
      default: {
        fprintf(stderr, "[ERROR] comparision for type = %d is undefined\n", Lexp->valueType);
        return;
      }
    }
    return;
  }
  case OP_EQ:
  case OP_NE: {
    struct nodeType *Lexp = nthChild(1, node); 
    struct nodeType *Rexp = nthChild(2, node);
    genCode(Lexp, fname);
    genCode(Rexp, fname);
    switch(Lexp->valueType) {
      case TypeInt: {
        switch(node->op) {
          case OP_EQ: {
            SHOW("Int OP_EQ");
            fprintf(fd, "\tif_icmpne %s\n", nlabel);
            return;
          }
          case OP_NE: {
            SHOW("Int OP_NE");
            fprintf(fd, "\tif_icmpeq %s\n", nlabel);
            return;
          }
        }
        break;
      }
      case TypeReal: {
        switch(node->op) {
          case OP_EQ: {
            SHOW("Real OP_EQ");
            fprintf(fd, "\tdcmpl\n\tifne %s\n", nlabel);
            return;
          }
          case OP_NE: {
            SHOW("Real OP_NE");
            fprintf(fd, "\tdcmpl\n\tifeq %s\n", nlabel);
            return;
          }
        }
        break;
      }
      default: {
        fprintf(stderr, "[ERROR] comparision for type = %d is undefined\n", Lexp->valueType);
        return;
      }
    }
    return;
  }
  case OP_NOT: {
    SHOW("OP_NOT");
    struct nodeType *exp = nthChild(1, node);
    negateOperator(exp);
    if(exp->op == OP_NO) SHOW("is op_no");
    else SHOW("IS NOT OP_NO");
    genPredicate(exp, nlabel, fname);
    return;
  }
  case OP_NO: {
    SHOW("OP_NO");
    struct nodeType *exp = nthChild(1, node);
    genPredicate(exp, nlabel, fname);
    return;
    }
  default:{SHOW("no match");}
  }
}
int getProgScope(char *funproc_name) {
  int index = findSymbolAt(funproc_name, 0);
  switch(SymbolTable.entries[index].type) {
    case TypeFun: {
      struct FunctionDsrpt *fun = (struct FunctionDsrpt *)SymbolTable.entries[index].typeDsrpt;
      return fun->scope;
    }
    case TypeProc: {
      struct ProcedureDsrpt *proc = (struct ProcedureDsrpt *)SymbolTable.entries[index].typeDsrpt;
      return proc->scope;
    }
  }
}
void genPostLude(char *funproc_name) {
  SHOW("genPostLude");
  int index = findSymbolAt(funproc_name, 0);
  switch(SymbolTable.entries[index].type) {
    case TypeFun: {
      struct FunctionDsrpt *fun = (struct FunctionDsrpt *)SymbolTable.entries[index].typeDsrpt;
      switch(fun->retType->type) {
        case TypeInt: {
          SHOW("genPostLude TypeFun TypeInt");
          int index = findSymbolAt(funproc_name, depth - 1);
          printf("funproc_name = %s\n", funproc_name);
          printf("depth = %d\n", depth);
          printf("\tiload %d\n\tireturn\n", SymbolTable.entries[index].index);
          printf("index = %d\n", index);
          fprintf(fd, "\tiload %d\n\tireturn\n", SymbolTable.entries[index].index);
          return;
        }
        case TypeReal: {
          SHOW("genPostLude TypeFun TypeReal");
          int index = findSymbolAt(funproc_name, depth);
          fprintf(fd, "\tdload %d\n\tdreturn\n", SymbolTable.entries[index].index);
          return;
        }
        case TypeChar: {
          SHOW("genPostLude TypeFun TypeChar");
          int index = findSymbolAt(funproc_name, depth);
          fprintf(fd, "\taload %d\n\tareturn\n", SymbolTable.entries[index].index);
          return;
        }
        default: fprintf(stderr, "Return type = %d is not implemented\n", fun->retType->type); exit(1);
      }
    }
    case TypeProc: {
      SHOW("genPostLude TypeProc");
      fprintf(fd, "\treturn\n");
      return;
    }
  }
}

void genTestCode() {
  fprintf(fd, ".class public fibonacci_recursive\n"
              ".super java/lang/Object\n"
              ".field public static a I\n"
              ".method public static writelnI(I)V\n"
              ".limit locals 5\n"
              ".limit stack 5\n"
              "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
              "iload 0\n"
              "invokevirtual java/io/PrintStream/println(I)V\n"
              "return\n"
              ".end method\n"
              "\n"
              ".method public static writelnR(F)V\n"
              ".limit locals 5\n"
              ".limit stack 5\n"
              "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
              "fload 0\n"
              "invokevirtual java/io/PrintStream/println(F)V\n"
              "return\n"
              ".end method\n"
              "\n"
              ".method public static writelnS(Ljava/lang/String;)V\n"
              ".limit locals 5\n"
              ".limit stack 5\n"
              "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
              "aload 0\n"
              "invokevirtual java/io/PrintStream/println(Ljava/lang/String;)V\n"
              "return\n"
              ".end method\n"
              "\n"
              ".method public static readlnI()I\n"
              ".limit locals 10\n"
              ".limit stack 10\n"
              "ldc 0\n"
              "istore 1\n"
              "LAB1:\n"
              "getstatic java/lang/System/in Ljava/io/InputStream;\n"
              "invokevirtual java/io/InputStream/read()I\n"
              "istore 2\n"
              "iload 2\n"
              "ldc 10\n"
              "isub\n"
              "ifeq LAB2\n"
              "iload 2\n"
              "ldc 32\n"
              "isub\n"
              "ifeq LAB2\n"
              "iload 2\n"
              "ldc 48\n"
              "isub\n"
              "ldc 10\n"
              "iload 1\n"
              "imul\n"
              "iadd\n"
              "istore 1\n"
              "goto LAB1\n"
              "LAB2:\n"
              "iload 1\n"
              "ireturn\n"
              ".end method\n"
              "\n"
              ".method public <init>()V\n"
	            "aload_0\n"
	            "invokenonvirtual java/lang/Object/<init>()V\n"
	            "return\n"
              ".end method\n"
              ".method public static printInt(I)V\n"
	            ".limit locals 1\n"
	            ".limit stack 2\n"
	            "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
	            "iload_0\n"
	            "invokevirtual java/io/PrintStream/println(I)V\n"
	            "return\n"
              ".end method\n"
              ".method public static printReal(D)V\n"
	            ".limit locals 2\n"
	            ".limit stack 3\n"
	            "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
	            "dload_0\n"
	            "invokevirtual java/io/PrintStream/println(D)V\n"
	            "return\n"
              ".end method\n"
              ".method public static printString(Ljava/lang/String;)V\n"
	            ".limit locals 1\n"
	            ".limit stack 2\n"
	            "getstatic java/lang/System/out Ljava/io/PrintStream;\n"
	            "aload_0\n"
	            "invokevirtual java/io/PrintStream/println(Ljava/lang/String;)V\n"
	            "return\n"
              ".end method\n"
              "\n"
              ".method public static fa(I)I\n"
	            ".limit stack 6\n"
	            ".limit locals 3\n"
	            "iload 0\n"
	            "ldc 1\n"
	            "if_icmpne L0\n"
	            "ldc 1\n"
	            "istore 1\n"
	            "goto L1\n"
              "L0:\n"
	            "iload 0\n"
	            "ldc 0\n"
	            "if_icmpne L2\n"
	            "ldc 0\n"
	            "istore 1\n"
	            "goto L3\n"
              "L2:\n"
	            "iload 0\n"
	            "ldc 1\n"
	            "isub\n"
	            "invokestatic fibonacci_recursive.fa(I)I\n"
	            "iload 0\n"
  	          "ldc 2\n"
	            "isub\n"
	            "invokestatic fibonacci_recursive.fa(I)I\n"
	            "iadd\n"
	            "istore 1\n"
              "L3:\n"
              "L1:\n"
	            "iload 1\n"
	            "ireturn\n"
              ".end method\n"
              "\n"
              ".method public static main([Ljava/lang/String;)V\n"
	            ".limit stack 20\n"
	            ".limit locals 10\n"
	            "invokestatic fibonacci_recursive.readlnI()I\n"
	            "putstatic fibonacci_recursive.a I\n"
	            "getstatic fibonacci_recursive.a I\n"
	            "invokestatic fibonacci_recursive.fa(I)I\n"
	            "invokestatic fibonacci_recursive.writelnI(I)V\n"
	            "return\n"
              ".end method\n");
}

void genCode(struct nodeType *node, char *fname) {
  switch(node->nodeType) {
    case NODE_PROGRAM: {
      SHOW("NODE_PROGRAM");
      char fn[128];
      prog = "fibonacci_recursive";
      sprintf(fn, "%s.s", prog);
      fd = fopen(output ? output : fn, "w");
      fname[strlen(fname)-2] = 0;
      depth = label_num = 0;
      //genTestCode();
      
      genHeader(fname); int varnum = 10; genGlobalVar(); genMethodDeclar();
      genCode(nthChild(5, nthChild(3, node)), fname);
      genBodyHead(fname, varnum);
      genAllocArray(0, fname);
      genCode(nthChild(4, node), fname);
      //fprintf(fd, "ldc 20\n");
      //fprintf(fd, "invokestatic test_array_slice.writelnI(I)V\n");
      genBodyEnd();
      
      fclose(fd);
      return; 
  }
  case NODE_SUBPROG: {
    SHOW("NODE_SUBPROG");
    struct nodeType *head = nthChild(1, node);
    struct nodeType *stmt = nthChild(3, node);
    struct nodeType *nameNode = nthChild(1, head);
    fprintf(fd, ".method public static %s\n", genSignature(nameNode->string));
    depth = getProgScope(nameNode->string);
    int varnum = genVar(depth);
    fprintf(fd, "\t.limit stack %d\n\t.limit locals %d\n", varnum*2, varnum);
    //fprintf(fd, "ldc -1\n");
    //fprintf(fd, "invokestatic test_array_slice.writelnI(I)V\n");
    genAllocArray(depth, fname);
    genCode(stmt, fname);
    genPostLude(nameNode->string);
    depth = 0;
    fprintf(fd, ".end method\n");
    return;
  }
  case NODE_VAR_OR_PROC: {
    SHOW("NODE_VAR_OR_PROC");
    int index = findSymbolAll(node->string, depth);
    printf("Current symbol is %s, depth is %d, index = %d\n", node->string, depth, index);
    struct SymTableEntry entry = SymbolTable.entries[index];
    switch(entry.type) {
      case TypeInt: {
        SHOW("NODE_VAR_OR_PROC TypeInt");
        if(entry.index == -1) {
          SHOW("getstatic");
          SHOW(node->string);
          if (entry.defined == 0) {
            fprintf(fd, "\tldc 0\n\tputstatic %s.%s\n", fname, genField(node->string));
            SymbolTable.entries[index].defined = 1;
          }
          fprintf(fd, "\tgetstatic %s.%s\n", fname, genField(node->string));
        }
        else {
          SHOW("iload");
          fprintf(fd, "\tiload %d\n", entry.index);
        }
        return;
      }
      case TypeReal: {
        SHOW("NODE_VAR_OR_PROC TypeReal");
        if(entry.index == -1) {
          if (entry.defined == 0) {
            fprintf(fd, "\tldc 0.0\n\tputstatic %s.%s\n", fname, genField(node->string));
            SymbolTable.entries[index].defined = 1;
          }
          fprintf(fd, "\tgetstatic %s.%s\n", fname, genField(node->string));
        }
        else fprintf(fd, "\tdload %d\n", entry.index);
        return;
      }
      case TypeChar: case TypeArray: {
        SHOW("NODE_VAR_OR_PROC TypeChar/Array");
        if(entry.index == -1) {
          if (entry.defined == 0) {
            fprintf(fd, "\tldc \"\"\n\tputstatic %s.%s\n", fname, genField(node->string));
            SymbolTable.entries[index].defined = 1;
          }
          fprintf(fd, "\tgetstatic %s.%s\n", fname, genField(node->string));
        }
        else fprintf(fd, "\taload %d\n", entry.index);
        return;
      }
      case TypeFun:
      case TypeProc: {
        SHOW("NODE_VAR_OR_PROC TypeFunProc");
        fprintf(fd, "\tinvokestatic %s.%s\n", fname, genSignature(node->string));
        return;
      }
      default: { fprintf(stderr, "Determing Var_or_Proc for Type %d unimplemented\n", entry.type); }
    }
    return; 
  }
  case NODE_SYM_REF: {
    SHOW("NODE_SYM_REF");
    struct nodeType *nameNode = nthChild(1, node);
    if(checkReference(nameNode) == 1) genArrayRef(node, fname);      
    else {
      int index = findSymbolAll(node->string, depth);
      struct SymTableEntry entry = SymbolTable.entries[index];
      switch(entry.type) {
        case TypeInt: {
          SHOW("NODE_SYM_REF TypeInt");
          fprintf(fd, "\tiload %d\n", entry.index);
          return;
        }
        case TypeReal: {
          SHOW("NODE_SYM_REF TypeReal");
          fprintf(fd, "\tdload %d\n", entry.index);
          return;
        }
        case TypeChar: {
          SHOW("NODE_SYM_REF TypeChar");
          fprintf(fd, "\taload %d\n", entry.index);
          return;
        }
        default: {
          SHOW("NODE_SYM_REF default");
          fprintf(stderr, "Symbol reference for Type %d unimplemented\n", entry.type);
        }
      }
    }
    return; 
  }
  case NODE_OP: {
    SHOW("NODE_OP");
    switch(node->op){
      case OP_ADD:
      case OP_SUB:
      case OP_MUL:
      case OP_DIV: {
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        if (Lexp->valueType == TypeChar && node->op == OP_ADD) {
          fprintf(fd, "\tnew java/lang/StringBuffer\n\tdup\n");
          fprintf(fd, "\tinvokespecial java/lang/StringBuffer/<init>()V\n");
          genCode(Lexp, fname);
          fprintf(fd, "\tinvokevirtual java/lang/StringBuffer/append(Ljava/lang/String;)Ljava/lang/StringBuffer;\n");
          genCode(Rexp, fname);
          fprintf(fd, "\tinvokevirtual java/lang/StringBuffer/append(Ljava/lang/String;)Ljava/lang/StringBuffer;\n");
          fprintf(fd, "\tinvokevirtual java/lang/StringBuffer/toString()Ljava/lang/String;\n");
          return;
        }
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        switch(Lexp->valueType) {
          case TypeInt:{
            switch(node->op) {
              case OP_ADD: print("iadd"); break;
              case OP_SUB: print("isub"); break;
              case OP_MUL: print("imul"); break;
              case OP_DIV: print("idiv"); break;
              }
              break;
          }
          case TypeReal:{
            switch(node->op) {
              case OP_ADD: print("fadd"); break;
              case OP_SUB: print("fsub"); break;
              case OP_MUL: print("fmul"); break;
              case OP_DIV: print("fdiv"); break;
            }
            break;
          }
          default: {
            fprintf(stderr, "Operation for Type %d unimplemented\n", Lexp->valueType);
          }
        }
        return;
      }
      case OP_NOT: {
        SHOW("NOT");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        //genCode(Lexp, fname);
        genCode(Rexp, fname);
        char *nlabel = genLabel();
        char *endlabel = genLabel();
        //printf("label is %s\n", nlabel);
        //printf("label is %s\n", endlabel);
        fprintf(fd, "\tifne %s\n", nlabel);
        fprintf(fd, "\tldc 1\n");
        fprintf(fd, "\tgoto %s\n", endlabel);
        fprintf(fd, "%s:\n", nlabel);
        fprintf(fd, "\tldc 0\n");
        fprintf(fd, "\tgoto %s\n", endlabel);
        fprintf(fd, "%s:\n", endlabel);
        return;
      }
      case OP_GT: {
        SHOW("OP_GT");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmpgt %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      case OP_LT: {
        SHOW("OP_GT");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmplt %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc -1\n");
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      case OP_GE: {
        SHOW("OP_GE");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmpge %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc -1\n");
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      case OP_LE: {
        SHOW("OP_GT");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmple %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      case OP_EQ: {
        SHOW("OP_EQ");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tif_icmpne %s\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      case OP_NE: {
        SHOW("OP_NE");
        struct nodeType *Lexp = nthChild(1, node);
        struct nodeType *Rexp = nthChild(2, node);
        genCode(Lexp, fname);
        genCode(Rexp, fname);
        if (Lexp->valueType == TypeInt) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tif_icmpne %s\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        else if (Lexp->valueType == TypeReal) {
          char *nlabel = genLabel();
          char *endlabel = genLabel();
          fprintf(fd, "\tfcmpg\n");
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tif_icmpeq %s\n", nlabel);
          fprintf(fd, "\tldc 1\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", nlabel);
          fprintf(fd, "\tldc 0\n");
          fprintf(fd, "\tgoto %s\n", endlabel);
          fprintf(fd, "%s:\n", endlabel);
        }
        return;
      }
      default: { return; }
    }
    break;
  }
  case NODE_ASSIGN_STMT: {
    SHOW("NODE_ASSIGN_STMT");
    struct nodeType *LHS = nthChild(1, node);
    struct nodeType *RHS = nthChild(2, node);
    switch(LHS->valueType) {
      case TypeInt: {
        int check = checkReference(LHS);
        switch(check) {
          case 0: {
            SHOW("NODE_ASSIGN_STMT LHS Int 0");
            SHOW(LHS->string);
	          int index = genSimpleLHS(LHS);
            printf("index = %d\n", index);
            genCode(RHS, fname); 
	          if(index == -1) {
              SHOW("putstatic");
              SHOW(fname);
              SHOW(genField(LHS->string)); 
              fprintf(fd, "\tputstatic %s.%s\n", fname, genField(LHS->string));
              int index = findSymbolAll(LHS->string, depth);
              SymbolTable.entries[index].defined = 1;
              printf("SymbolTable.entries[%d].defined = %d\n", index, SymbolTable.entries[index].defined);
            }
	          else {
              SHOW("istore");
              fprintf(fd, "\tistore %d\n", index);
            }
            return;
          }
          case 1: {
            SHOW("NODE_ASSIGN_STMT LHS Int 1");
	          genArrayLHS(LHS, fname);
            genCode(RHS, fname); 
	          fprintf(fd, "\tiastore\n");
            return;
          }
        }
      }
      case TypeReal: {
        int check = checkReference(LHS);
        switch(check) {
          case 0: {
            SHOW("NODE_ASSIGN_STMT LHS Real 0");
            int index = genSimpleLHS(LHS);
            genCode(RHS, fname);
            if(index == -1) {
              fprintf(fd, "\tputstatic %s.%s\n", fname, genField(LHS->string));
              int index = findSymbolAll(LHS->string, depth);
              SymbolTable.entries[index].defined = 1;
              printf("SymbolTable.entries[%d].defined = %d\n", index, SymbolTable.entries[index].defined);
            }
            else fprintf(fd, "\tdstore %d\n", index);
            return;
          }
          case 1: {
            SHOW("NODE_ASSIGN_STMT LHS Real 1");
	          genArrayLHS(LHS, fname);
            genCode(RHS, fname);
            fprintf(fd, "\tdastore\n");
            return;
          }
        }
      }
      case TypeChar: {
        int check = checkReference(LHS);
        switch(check) {
          case 0: {
            int index = genSimpleLHS(LHS);
            genCode(RHS, fname);
            if(index == -1) {
              fprintf(fd, "\tputstatic %s.%s\n", fname, genField(LHS->string));
              int index = findSymbolAll(LHS->string, depth);
              SymbolTable.entries[index].defined = 1;
              printf("SymbolTable.entries[%d].defined = %d\n", index, SymbolTable.entries[index].defined);
            }
            else fprintf(fd, "\tastore %d\n", index);
            return;
          }
          case 1: {
            genArrayLHS(LHS, fname); genCode(RHS, fname);
            fprintf(fd, "\taastore\n");
            return;
          }
        }
      }
      default: { fprintf(stderr, "Assignment for Type %d unimplemented\n", LHS->valueType); }
    }
    return; 
  }
  case NODE_PROC_STMT: {
    SHOW("NODE_PROC_STMT");
    struct nodeType *nameNode = nthChild(1, node);
    struct nodeType *expList = nthChild(2, node);
    genCode(expList, fname);
    fprintf(fd, "\tinvokestatic %s.%s\n", fname, genSignature(nameNode->string));
    return;
  }
  case NODE_IF: {
    SHOW("NODE_IF");
    struct nodeType *predicate = nthChild(1, node);
    struct nodeType *ifstmt = nthChild(2, node);
    struct nodeType *elsestmt = nthChild(3, node);
    char *nlabel = genLabel();
    char *endlabel = genLabel();
    genPredicate(predicate, nlabel, fname);
    genCode(ifstmt, fname);
    SHOW("GOTO");
    fprintf(fd, "\tgoto %s\n", endlabel);
    SHOW("nlabel");
    fprintf(fd, "%s:\n", nlabel);
    genCode(elsestmt, fname);
    SHOW("endlabel");
    fprintf(fd, "%s:\n", endlabel);    
    return; 
  }
  case NODE_WHILE: {
    SHOW("NODE_WHILE");
    struct nodeType *predicate = nthChild(1, node);
    struct nodeType *stmt = nthChild(2, node);
    char *looplabel = genLabel();
    char *endlabel = genLabel();
    fprintf(fd, "%s:\n", looplabel);
    genPredicate(predicate, endlabel, fname);
    genCode(stmt, fname);
    fprintf(fd, "\tgoto %s\n", looplabel);
    fprintf(fd, "%s:\n", endlabel);
    return; 
  }
  case NODE_FOR: { fprintf(stderr, "FOR unimplemented\n"); break; }
  case NODE_REPEAT: { fprintf(stderr, "REPEAT unimplemented\n"); break; }
  case NODE_WITH: { fprintf(stderr, "WITH unimplemented\n"); break; }
  case NODE_GOTO: { fprintf(stderr, "GOTO unimplemented\n"); break; }
  case NODE_INT: { fprintf(fd, "\tldc %d\n", node->iValue); return; }
  case NODE_REAL: { fprintf(fd, "\tldc %lf\n", node->rValue); return; }
  case NODE_CHAR: { fprintf(fd, "\tldc %s\n", node->string); return; }
  case NODE_LABEL: { node->valueType = TypeLabel; return; }
  }
  /* default action for other nodes */
  struct nodeType *child = node->child;
  if(child != 0) {
    do {
      genCode(child, fname);
      child = child->rsibling;
    } while(child != node->child);
  }
}