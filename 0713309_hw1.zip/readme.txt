[How to execute this program]
< make >
< ./scanner scanner-test00.p >
//<make test> failed all testcases just because of the different format of output, so please run and check one-by-one
//I am sorry for noticing this too late, if this fault will cause 0 score, please give me a chance to modify it!!

[Details]
1. About Testcases:
Almost same as those in ScanTestCases, the below are differences:

File                              position   Original                Modified
scanner-test01.p                  line 28    'This is a srting!!';   "This is a srting!!";
scanner-test01.p                  line 34    '{}<>?:                 "{}<>?:
scanner-test03-runaway-string.p   line 10    'This is a srting!!';   "This is a srting!!";


2. About Numbers
There are 3 types of numbers, INTEGERNUM, REALNUMBER, and SCIENTIFIC.
All of them are classified into "NUMBER" type, (but the type number is different, so we can distinguish them.)


3. About Strings
Begins and ends with double quotes ' " ', may span multiple lines.
Runaway Strings will be taken as an error.


4. About Comments
For multiple-line comments, the scanner will print "[INFO ] comment string start" when it sees a "/*".
After this, once it sees a "*/", the comment ends immediately, and will print "[INFO ] comment string end".
This scanner can NOT handle nested comments.
Runaway Comments will be taken as an error.


5. Differences Between My Result & the Answer Given

I checked my scanner with all of the testcases, except for "scanner-test03-nested-comments.p", since it can not be handled.
Some of the type number, line number, char number may be different.
that's not that important, so I only list out the "tokens" or "comments" which are scanned differently as the answer and explain why. 

In line 16, scanner-test03-runaway-string.p
"cross 
         line string;
      a := 5 +bb;
   end.   // this is the end of the program

MY RESULT:
[ERROR] line   15: runaway string "cross 
         line string;
      a := 5 +bb;
   end.   // this is the end of the program

ANSWER:
[ERROR] line   16: 15 runaway string "cross 
  58-th token(type:IDENTIFIER-500) on line   17,  10 : line
  59-th token(type:KEYWORD   -306) on line   17,  15 : string
  60-th token(type:KEYWORD   -402) on line   17,  21 : ;
  61-th token(type:IDENTIFIER-500) on line   18,   7 : a
  62-th token(type:KEYWORD   -409) on line   18,   9 : :=
  63-th token(type:NUMBER    -501) on line   18,  12 : 5
  64-th token(type:KEYWORD   -410) on line   18,  14 : +
  65-th token(type:IDENTIFIER-500) on line   18,  15 : bb
  66-th token(type:KEYWORD   -402) on line   18,  17 : ;
  67-th token(type:KEYWORD   -310) on line   19,   4 : end
  68-th token(type:KEYWORD   -407) on line   19,   7 : .
[INFO ] line   19: 11 comment string // this is the end of the program

REASON:
It seems that the code that generate the answer express the runaway string like this:
["][^"]*[\r\n]
But I don't think this is correct because a string may span multiple lines, so what if there is another ["] several lines after?
Therefore, I consider that all things behind the first ["] should be taken as runaway strings, until another ["] appears.
-----------------------------------------------------------------------

In line 34, scanner-test01.p
"{}<>?:
   end.   // this is the end of the program

MY RESULT:
[ERROR ] line   33: runaway string "{}<>?:
   end.   // this is the end of the program

ANSWER:
[ERROR] line   34: 52 runaway string "{}<>?:
 217-th token(type:KEYWORD   -310) on line   35,   4 : end
 218-th token(type:KEYWORD   -407) on line   35,   7 : .
[INFO ] line   35: 11 comment string // this is the end of the program

REASON:
Same as the above.
-----------------------------------------------------------------------

In line 38, strange-token.p
'''' 

MY RESULT:
[ERROR ] line   38:  1 lexical analyzer error '
[ERROR ] line   38:  2 lexical analyzer error '
[ERROR ] line   38:  3 lexical analyzer error '
[ERROR ] line   38:  4 lexical analyzer error '

ANSWER:
70-th token(type:STRING    -503) on line   38,   1 : ''''

REASON:
Because we do NOT use ['] as string token.
If we changed line 38 to be ""
Then this will be correct.
-----------------------------------------------------------------------

In line 7, Comments.p

MY RESULT:
[INFO ] line 7: comment string start
/*  
    NotId
    12345
    123.456E+55
    "Hello World"
    // Nested C Style comments
    /*Nested C++ Style Comments */
[INFO ] line 13: comment string end
   0-th token(type:KEYWORD   -412) on line   14,   1 : *
   1-th token(type:KEYWORD   -413) on line   14,   2 : /

ANSWER:
[INFO ] line    7:  1 comment string start
/*  
    NotId
    12345
    123.456E+55
    "Hello World"
    // Nested C Style comments
    /* Nested C++ Style Comments */
*/
[INFO ] line   14:  1 comment string end

REASON:
Since this scanner can not handle nested comments.
Instead, it ends a comment once it sees the first "*/".
Therefore, the last two char are not seen as part of comments, they are seen as tokens.
--------------------------------------------------------------------------

Thanks For Reaching Here :))
